ANT_HOME="/usr/share/java/apache-ant"
export ANT_HOME
